/**
 * Spring Data Elasticsearch repositories.
 */
package com.ocbc.soa.repository.search;
