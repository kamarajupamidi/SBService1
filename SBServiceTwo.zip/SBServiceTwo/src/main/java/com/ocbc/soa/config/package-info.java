/**
 * Spring Framework configuration files.
 */
package com.ocbc.soa.config;
