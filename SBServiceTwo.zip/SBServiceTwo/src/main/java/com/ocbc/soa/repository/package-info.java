/**
 * Spring Data JPA repositories.
 */
package com.ocbc.soa.repository;
