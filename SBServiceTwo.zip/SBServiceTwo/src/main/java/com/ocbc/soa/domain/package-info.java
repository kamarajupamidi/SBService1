/**
 * JPA domain objects.
 */
package com.ocbc.soa.domain;
