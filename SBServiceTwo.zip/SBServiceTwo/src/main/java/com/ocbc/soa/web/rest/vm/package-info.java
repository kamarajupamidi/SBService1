/**
 * View Models used by Spring MVC REST controllers.
 */
package com.ocbc.soa.web.rest.vm;
